import { Component } from '@angular/core';

@Component({
  selector: 'page-peer-ionic',
  templateUrl: 'peer.html'
})
export class PeerModule {
  constructor() {

  }
}
