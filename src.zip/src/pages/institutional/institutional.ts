import { Component } from '@angular/core';
import { IonicPage } from 'ionic-angular';
//import { RootScope } from '../../providers/root-scope';
//import { AuthService } from '../../providers/auth-service';

@IonicPage()
@Component({
    selector: 'page-institutional',
    templateUrl: 'institutional.html',
})
export class InstitutionalPage {

    
}
