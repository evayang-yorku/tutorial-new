import { Component } from '@angular/core';
import { IonicPage } from 'ionic-angular';
//import { RootScope } from '../../providers/root-scope';
//import { AuthService } from '../../providers/auth-service';

@IonicPage()
@Component({
    selector: 'page-about',
    templateUrl: 'about.html',
})
export class AboutUsPage {

    //infoPage: any;

    // slides = [
    //     {
    //         title: "Welcome to Indigenous Friends!",
    //         description: "If you have just finished registering <b>PLEASE NOW, LOG-IN!</b>",
    //         image: "assets/img/1.png",
    //     }
    // ];

    // constructor(public navCtrl: NavController, public navParams: NavParams, private rootScope: RootScope, private authService: AuthService) {
    //     this.infoPage = this.rootScope.pagesInit[9];
    // }

    // ionViewDidLoad() {
    //     console.log('ionViewDidLoad TutorialPage');
    // }

    // ionViewDidEnter() {
    //     this.rootScope.currentPage = this.infoPage;
    // }
}