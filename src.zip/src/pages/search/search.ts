import { Component } from '@angular/core';

@Component({
  selector: 'page-search-ionic',
  templateUrl: 'search.html'
})
export class SearchPage {
  constructor() {

  }
}
