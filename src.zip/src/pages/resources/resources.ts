import { Component } from '@angular/core';

@Component({
  selector: 'page-resources-ionic',
  templateUrl: 'resources.html'
})
export class ResourcesPage {
  constructor() {

  }
}
