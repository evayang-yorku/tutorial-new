import { Component } from '@angular/core';

@Component({
  selector: 'page-chats-ionic',
  templateUrl: 'chats.html'
})
export class ChatsPage {
  constructor() {

  }
}
