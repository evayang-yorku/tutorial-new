import { Component } from '@angular/core';

@Component({
  selector: 'page-profile-ionic',
  templateUrl: 'profile.html'
})
export class ProfilePage {
  constructor() {

  }
}
